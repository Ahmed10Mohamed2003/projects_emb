#include "APP/APP_interface.h"
#include"util/delay.h"
#include "LIB/STD_TYPES.h"
#include "LIB/BIT_MATH.h"
#include "MCAL/DIO/DIO_interface.h"
#include "HAL/EEPROM/EEPROM_Interface.h"
#include "HAL/BLUETOOTH/BLUETOOTH_interface.h"
#include "HAL/LCD/LCD_interface.h"
#include "HAL/LEDS/LEDS_interface.h"
#include "HAL/FAN/Fan_interface.h"
#include "HAL/DOOR/DOOR_interface.h"
#include "MCAL/EXTI/GI_interface.h"
extern u8 Gas_leakage_Last;
int main(void)
{
	APP_voidInit();
	APP_voidLogin();
    Fan_u8StopFan();

    Door_voidinit();

   while(1)
   {
	  if(MQ2_IsThierGasLeakage())
	   {
		   u8 Counter;
		   TurnON_Buzzer();
		   _delay_ms(1000);
		   TurnOFF_Buzzer();
		   //store in EEPROM number of Gas Leakage
		   Gas_leakage_Last++;
		   //EEPROM_voidSendDataByte(4,Gas_leakage_Last);
		   //TurnON_Buzzer();

	   }
	  //TurnON_Buzzer();

  // LDR_voidUpdate();
   }
}



