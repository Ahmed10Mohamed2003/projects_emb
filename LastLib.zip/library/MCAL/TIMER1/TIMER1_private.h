/*
 * TIMER1_private.h
 *
 *  Created on: Oct 18, 2024
 *      Author: yousef.ahmed
 */

#ifndef TIMER1_PRIVATE_H_
#define TIMER1_PRIVATE_H_

#define TCNT1        *((volatile u16*)0X4C)
#define TCCR1A       *((volatile u8*)0x4F)
#define TCCR1B       *((volatile u8*)0x4E)
#define OCR1A        *((volatile u16*)0X4A)
#define ICR1         *((volatile u16*)0X46)
#define TIMSK       *((volatile u8*)0X59)




#endif /* TIMER1_PRIVATE_H_ */
