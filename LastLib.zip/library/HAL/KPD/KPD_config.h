#ifndef KPD_CONFIG_H_
#define KPD_CONFIG_H_



#define KPD_PORT           DIO_u8_PORTB


#define R0           DIO_u8_PIN0
#define R1           DIO_u8_PIN1
#define R2           DIO_u8_PIN4
#define R3           DIO_u8_PIN3


#define C0           DIO_u8_PIN5
#define C1           DIO_u8_PIN6
#define C2           DIO_u8_PIN7
#define C3           DIO_u8_PIN7


#define MAX_ROW_NUM           3
#define MAX_COL_NUM           3

#define KPD_VALUES         {{1,2,3},\
                            {4,5,6},\
							{7,8,9}}


#define NO_PRESSED_KEY            255



#endif
