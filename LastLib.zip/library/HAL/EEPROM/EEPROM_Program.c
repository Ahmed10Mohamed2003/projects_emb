/***************************************************************************************/
/****************************  IMT School Training Center ******************************/
/***************************************************************************************/
/** This file is developed by IMT School training center, All copyrights are reserved **/
/***************************************************************************************/
#include "LIB/STD_TYPES.h"
#define F_CPU	8000000UL
//#include <util/delay.h>
#include "LIB/delay.h"

#include "MCAL/TWI/TWI_interface.h"
#include "MCAL/DIO/DIO_interface.h"
#include "HAL/EEPROM/EEPROM_Interface.h"
#include "HAL/EEPROM/EEPROM_Config.h"
#include "HAL/EEPROM/EEPROM_Private.h"
void EEPROM_voidInit(void)
{
	TWI_voidInitMaster(0);
}
/*********************************************************************************/
/* Function: EEPROM_voidSendDataByte	                       				    **/
/* I/P Parameters: u16 Copy_u16LocationAddress, u8 Copy_u8DataByte   		    **/
/* Returns:it returns No thing                                				    **/
/* Desc:This Function sends byte of data to eeprom								**/
/*********************************************************************************/
/* Copy_u16LocationAddress:the address of the location you want to write on		**/
/* Copy_u8DataByte:Assign the Data you want to send								**/
/*********************************************************************************/
void EEPROM_voidSendDataByte(u16 Copy_u16LocationAddress, u8 Copy_u8DataByte)
{
	u8 Local_u8AddressPacket;

	Local_u8AddressPacket = EEPROM_FIXED_ADDRESS | (A2_CONNECTION <<2) | (u8)(Copy_u16LocationAddress >>8);
	
	/*Send start condition*/
	TWI_ErrorStatusSendStartConditionWithACK();

	/*Send the address packet*/
	TWI_ErrorStatusSendSlaveAddressWithWriteACK(Local_u8AddressPacket);

	/*Send the rest 8bits of the location address*/
	TWI_ErrorStatusMasterWriteDataByteWithACK((u8)Copy_u16LocationAddress);

	/*Send the data byte to the memory location*/
	TWI_ErrorStatusMasterWriteDataByteWithACK(Copy_u8DataByte);

	/*Send stop condition*/
	TWI_voidSendStopCondition();

	/*Delay until the write cycle is finished*/
	delay_ms(20);

}

/*********************************************************************************/
/* Function: EEPROM_u8ReadDataByte		                       				    **/
/* I/P Parameters: u16 Copy_u16LocationAddress						  		    **/
/* Returns:it returns u8	                                				    **/
/* Desc:This Function reads a byte of data from eeprom							**/
/*********************************************************************************/
/* Copy_u16LocationAddress:the address of the location you want to read from	**/
/*********************************************************************************/
void EEPROM_u8ReadDataBytes(u16 Copy_u16StartAddress, u8 *Copy_pu8Buffer, u16 Copy_u16Length)
{
    u8 Local_u8AddressPacket;
    u16 i;

    /* Build device address packet */
    Local_u8AddressPacket = EEPROM_FIXED_ADDRESS
                            | (A2_CONNECTION << 2)
                            | (u8)(Copy_u16StartAddress >> 8);

    /* 1) Send START condition */
    TWI_ErrorStatusSendStartConditionWithACK();

    /* 2) Send device address + WRITE */
    TWI_ErrorStatusSendSlaveAddressWithWriteACK(Local_u8AddressPacket);

    /* 3) Send memory address low byte */
    TWI_ErrorStatusMasterWriteDataByteWithACK((u8)Copy_u16StartAddress);

    /* 4) Send REPEATED START */
    TWI_ErrorStatusSendRepeatedStartConditionWithACK();

    /* 5) Send device address + READ */
    TWI_ErrorStatusSendSlaveAddressWithReadACK(Local_u8AddressPacket);

    /* 6) Read bytes */
    for (i = 0; i < Copy_u16Length; i++)
    {
        if (i < (Copy_u16Length - 1))
        {
            /* Read with ACK to continue */
            TWI_ErrorStatusMasterReadDataByteWithACK(&Copy_pu8Buffer[i]);
        }
        else
        {
            /* Last byte: read with NACK to stop reading */
            TWI_ErrorStatusMasterReadDataByteWithNACK(&Copy_pu8Buffer[i]);
        }
    }

    /* 7) Send STOP condition */
    TWI_voidSendStopCondition();
}


