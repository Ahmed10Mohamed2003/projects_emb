#ifndef CLCD_CONFIG_H_
#define CLCD_CONFIG_H_



/*
 *Options:
 *PORT_u8A
 *PORT_u8B
 *PORT_u8C
 *PORT_u8D
 */
#define DATA_PORT    DIO_u8_PORTA

#define CTRL_PORT    DIO_u8_PORTC

#define RS      DIO_u8_PIN7
#define RW      DIO_u8_PIN6
#define EN      DIO_u8_PIN5


#endif
